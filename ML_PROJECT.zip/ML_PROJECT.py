import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
import tkinter as tk

# Dataset
data = {
    "Email":[
        "Win money now",
        "Claim your free prize",
        "Limited offer just for you",
        "Congratulations you won lottery",
        "Meeting at 5 pm",
        "Project submission tomorrow",
        "You have an interview tomorrow",
        "Team meeting today",
        "Job interview confirmation"
    ],

    "Label":[
        "Spam","Spam","Spam","Spam",
        "Not Spam","Not Spam","Not Spam","Not Spam","Not Spam"
    ]
}

df = pd.DataFrame(data)

X = df["Email"]
y = df["Label"]

vectorizer = CountVectorizer()
X_vec = vectorizer.fit_transform(X)

model = MultinomialNB()
model.fit(X_vec, y)

# Prediction function
def predict_email():
    email = entry.get()
    test = vectorizer.transform([email])
    result = model.predict(test)

    if result[0] == "Spam":
        output.config(text="🚨 This Email is SPAM", fg="red")
    else:
        output.config(text="✅ This Email is NOT SPAM", fg="green")


# GUI Window
window = tk.Tk()
window.title("Email Spam Detection System")
window.geometry("450x300")
window.config(bg="#f2f2f2")

title = tk.Label(window,
                 text="Email Spam Detection",
                 font=("Arial",16,"bold"),
                 bg="#f2f2f2")
title.pack(pady=10)

label = tk.Label(window,
                 text="Enter Email Text:",
                 font=("Arial",12),
                 bg="#f2f2f2")
label.pack()

entry = tk.Entry(window,
                 width=40,
                 font=("Arial",12))
entry.pack(pady=10)

btn = tk.Button(window,
                text="Check Email",
                font=("Arial",12,"bold"),
                bg="#4CAF50",
                fg="white",
                command=predict_email)
btn.pack(pady=10)

output = tk.Label(window,
                  text="",
                  font=("Arial",14,"bold"),
                  bg="#f2f2f2")
output.pack(pady=20)

window.mainloop()
